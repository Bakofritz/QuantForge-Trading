# QuantForge Strategy Optimization

This folder is the cumulative home for strategy backtesting and optimization evidence. Future builds append new run reports rather than replacing prior evidence.

## Evidence rules
- Market-data-backed performance results must identify instrument, contract/data source, timeframe, timezone/session, date range, bar count, costs, slippage/fill model, parameters, and causal execution policy.
- No synthetic data may be presented as market performance.
- Development/optimization results must be separated from validation and untouched forward periods when sufficient data exists.
- Same-bar execution is rejected unless an explicit close-auction model is selected; otherwise next-bar/next-eligible-tick execution is used.
- Missing or insufficient market data produces a blocked/incomplete report, not invented metrics.

## Current run
See `reports/Optimization_Run_v26.10.md`.
