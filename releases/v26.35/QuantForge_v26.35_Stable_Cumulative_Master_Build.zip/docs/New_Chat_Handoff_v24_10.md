# QuantForge v24.10 — New-Chat Handoff

Continue the QuantForge Master Build from v24.10 using this package as the cumulative source baseline.

## Completed through this release
- Governed strategy import and feature scrubbing.
- Read-only NT8/local market-data discovery and dataset identity.
- Multi-script simulation and simulation optimization.
- Walk-forward robustness analysis.
- AI read-only research analysis gate.
- Consolidated Research Release Gate.
- Hard live-brokerage lock remains active.

## Next safe direction
Continue only with cumulative research/simulation improvements that preserve read-only data, simulation-only execution, fail-closed behavior, and the separation between research authority and live/order authority.
