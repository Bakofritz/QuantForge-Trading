# QuantForge Consumer User Manual Audit — v26.05

## Audit purpose
This audit reviews the current user manual as a consumer-facing operating document: whether an average user can understand what QuantForge is, install the current build, identify the safe operating mode, import a strategy, run research/simulation, interpret results, and understand what is not yet available.

## Findings
### Strengths
- The authority boundary is explicit: research/simulation actions do not authorize live trading.
- The strategy-import workflow preserves originals and fingerprints source artifacts.
- Causal/no-forward-bias requirements are stated as hard rules.
- Multi-strategy simulation isolation is documented.
- Current imported-strategy status is separated from performance claims.

### Usability gaps addressed in v26.05
- Added a quick-start path before technical detail.
- Added a plain-language “What can I do right now?” section.
- Added a “What this build cannot do” section.
- Added installation/startup checklist and first-run checklist.
- Added strategy import walkthrough using the quarantine → audit → approval → research adapter flow.
- Added research workflow: backtest → walk-forward → replay → simulated forward test.
- Added result interpretation guidance and explicit distinction between smoke validation and performance backtests.
- Added troubleshooting and recovery guidance.
- Added glossary of technical terms.
- Added document-status/version information and release-gate limitations.

## Consumer usability target
The manual should allow a technically capable but non-developer user to complete a safe research workflow without needing to understand the internal architecture first. Technical architecture remains available in later sections for advanced users.

## Remaining usability limitation
Native Android/Windows installation and runtime steps cannot be claimed as fully validated until native builds and device/runtime tests are performed. The manual therefore labels those procedures as environment-dependent rather than presenting unverified steps as guaranteed.

## v26.10 follow-up audit
The manual was re-audited for the newly added strategy optimization workflow. The consumer-facing instructions now explain where cumulative optimization reports live, how to distinguish a real data-backed result from a blocked run, what metadata must accompany performance numbers, and why limited datasets are acceptable only when clearly labeled.
