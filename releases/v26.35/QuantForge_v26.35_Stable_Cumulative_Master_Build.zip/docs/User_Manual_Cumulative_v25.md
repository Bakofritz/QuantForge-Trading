# QuantForge User Manual — Cumulative v25

## Purpose
QuantForge v25 is a research, simulation, strategy-audit, and controlled forward-testing platform. The cumulative manual applies to the latest stable build unless a newer build section explicitly changes a procedure.

## Authority boundary
Importing, scrubbing, approving, backtesting, optimizing, or forward-testing a strategy does not authorize live trading. Live brokerage authentication and live order submission remain disabled.

## Strategy import workflow
1. Place source in quarantine.
2. Preserve the original bytes and calculate a SHA-256 fingerprint.
3. Run static source scrubbing and capability inventory.
4. Review safety-sensitive findings.
5. Select only the components permitted for research.
6. Complete governance review.
7. Create a read-only research capability manifest.
8. Sanitize/adapt into the canonical research interface.
9. Run causal and regression checks.
10. Register provenance and model fingerprints.
11. Backtest, walk forward, replay, and forward test under the causal execution rules.

## Causal execution rule
At observation time T, only information available at or before T may influence a signal. Future bars, future indicator values, and future completed higher-timeframe candles are prohibited. A causal-integrity violation is a hard rejection.

## Execution timing rule
A signal that uses the current completed bar cannot silently receive a same-bar fill. Same-bar execution requires an explicitly selected close-auction model. Otherwise use the next-bar-open or next-eligible-tick model.

## Multi-strategy forward testing
Every strategy receives an independent read-only feed instance, strategy state, simulated ledger, evidence/fingerprint chain, and isolated ledger namespace. Duplicate IDs, invalid capability manifests, fingerprint mismatches, or cross-strategy namespace mismatches are rejected.

## Imported strategies in the current research queue
- ZeroLagLiquidity: candidate after export-corruption cleanup and causal execution wrapping.
- VWAP Mean Reversion: candidate after explicit execution-timing correction and canonical ledger integration.
- Volume Sentiment Breakout Channels: indicator/signal-provider candidate; strategy conversion remains a separate controlled step.
- TrendRebalanceMapHerman: candidate pending confirmation of its directional semantics.
- Ultimate Strategy Template artifacts: reference/template material until complete executable source is available.

## Backtesting requirements
A performance backtest requires instrument-specific historical data, timeframe/tick definition, session calendar/timezone, tick size, point value, commissions, slippage/fill model, parameters, and separated development/validation/untouched forward periods. QuantForge must not invent performance metrics.

## Release gate
A stable research release requires: source scan passed; governance isolation passed; causal integrity passed; multi-strategy isolation passed; cumulative documentation updated; and live authority disabled.

## Current limitations
Native .NET compilation and native Android/Windows device execution are not verified in the current environment. These limitations do not change the research-only authority boundary.
