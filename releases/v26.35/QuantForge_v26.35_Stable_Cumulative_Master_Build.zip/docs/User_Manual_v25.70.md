# QuantForge User Manual — v25.70

## What this build is for
QuantForge v25.70 is a research and simulation build. It is designed to inspect imported strategy code, govern what parts may enter the research system, run causal historical/replay/forward tests, and keep every strategy's simulated account separate.

## Important authority boundary
Live brokerage and live order submission are disabled. Importing, scrubbing, approving, backtesting, optimizing, or forward-testing a strategy does not authorize live trading.

## Strategy import workflow
1. Put the source into quarantine.
2. Run the static source scrubber.
3. Review the feature inventory and safety-sensitive findings.
4. Select only the components you want considered for canonical research use.
5. Complete governance review for safety-sensitive capabilities.
6. Create a research-only capability manifest.
7. Register the strategy with its provenance/fingerprint chain.
8. Run regression tests before research use.

The original source must remain preserved separately from any cleaned or sanitized version.

## Multi-strategy forward testing
A multi-strategy batch uses independent strategy sessions. Each strategy gets:
- its own strategy state;
- its own simulated ledger;
- its own feed instance;
- its own evidence fingerprint;
- the same causal/no-forward-bias rules;
- no live-order authority.

A batch is rejected if strategy IDs are duplicated, a capability manifest is not research-only, or the strategy/model fingerprint does not match the approved model fingerprint (unless a controlled adapter explicitly documents the difference).

## Causal research rule
At observation time T, the strategy may use only information available at or before T. Future bars, future indicator values, and future completed higher-timeframe candles are prohibited. A causal-integrity violation is a hard rejection.

## Backtesting
A performance backtest requires, at minimum:
- instrument-specific historical OHLCV or tick data;
- bar interval or tick specification;
- exchange/session calendar and timezone;
- tick size and point value;
- commission assumptions;
- slippage/fill model;
- strategy parameters;
- development/validation/untouched forward-test separation.

Without these inputs, QuantForge may run structural or smoke tests but must not present invented performance metrics.

## Imported artifacts in v25.70
- ZeroLagLiquidity: research candidate after source-export cleanup and causal execution wrapping.
- VWAP Mean Reversion: research candidate after explicit execution-timing correction.
- Volume Sentiment Breakout Channels: indicator/signal-provider candidate.
- TrendRebalanceMapHerman: research candidate pending confirmation of directional semantics.
- Ultimate Strategy Template artifacts: reference/template material until complete executable source is available.

## User workflow for a new strategy
**Import → Scrub → Review → Select → Govern → Sanitize → Register → Backtest → Walk-forward → Forward test → Simulated deployment.**

Do not skip the governance or causal-integrity stages.

## Current build limitations
- Native .NET compilation is not claimed because the current environment does not have the .NET SDK.
- Native Android/Windows device validation is not claimed.
- Live broker authentication and live order submission are disabled.
- Actual performance results for the newly imported strategies require valid historical market data and explicit instrument specifications.
