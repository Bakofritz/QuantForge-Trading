# QuantForge Running New-Chat Handoff

This is the cumulative handoff record beginning after v24.50. Append new build-numbered sections rather than creating a new handoff file.

## v25.00–v25.40

- Starting baseline: **v24.50 validated Git commit `9e1ec3adaabb0fc480856d35f41d373fdf869ed2`**.
- Repository baseline was pushed to `main` and verified clean.
- v25.x work is additive and research-only.
- Consolidated iterations: v25.00, v25.05, v25.10, v25.15, v25.20, v25.25, v25.30, v25.35, v25.40.
- Preserve the v24.50 commit as the rollback/reference point.
- Do not enable live brokerage or live order submission.
- Future NT8 integration remains gated and does not unlock live trading merely because NT8 is running.

### Live-environment state and capabilities
- Live brokerage connection: **DISABLED**
- Live order submission: **DISABLED**
- Simulation: **ENABLED**
- Market data: **READ-ONLY**
- NT8: **future prerequisite only**
- Strategy import: **quarantined and governed**
- Optimization: **simulation-only**
- AI research: **read-only / simulation-only**
- AI application-setting modification: **DISABLED**
- Unknown/recovery states: **fail-closed**
- Production broker execution: **not implemented/validated**

## Continuation rule
Continue from the validated result of this consolidated build. Batch compatible, stable iterations rather than creating unnecessarily small releases.
