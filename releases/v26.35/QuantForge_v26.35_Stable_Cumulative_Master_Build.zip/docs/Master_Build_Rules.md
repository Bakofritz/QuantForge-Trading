# QuantForge Permanent Master Build Rules

1. Continue the Master Build through as many stable, auditable iterations as can be completed safely.
2. Every release reports milestone progress percentages.
3. Every release reports:
   - usable-state total progress;
   - full-functionality implementation progress;
   - historical-cadence ETA ranges for remaining work.
4. ETA estimates must be based on recorded build history and must show their basis; they are not guarantees.
5. As new timing evidence accumulates, the ETA model must be recalibrated.
6. Documentation is cumulative: append build-specific information to running master documents rather than generating a new duplicate documentation set for every small iteration.
7. Every release includes the simple live-environment state/capability summary.
8. Never claim native compilation, device execution, broker authentication, or production order submission unless it was actually performed and validated.
9. Preserve fail-closed separation among research, observation, live pathway, bot, order, and broker execution authorities.
