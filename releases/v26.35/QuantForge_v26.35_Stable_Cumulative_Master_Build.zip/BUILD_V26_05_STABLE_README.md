# QuantForge v26.05 — Stable Cumulative Master Build

This release carries forward v25.90 and applies three documentation/usability stability iterations: v25.95, v26.00, and v26.05.

The primary user-facing change is a production-value cumulative user manual with a consumer-first quick start, safe operating boundaries, import/research workflows, troubleshooting, checklists, glossary, and explicit validation limitations. A PDF publication is included alongside the Markdown source.

Live brokerage and live order submission remain disabled.

Use `docs/User_Manual_Cumulative_v26.05.md` for the current manual, `docs/Manual_Usability_Audit_v26.05.md` for the audit, and the release notes for the iteration history.
