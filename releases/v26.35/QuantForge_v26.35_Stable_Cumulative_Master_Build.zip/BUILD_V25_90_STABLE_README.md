# QuantForge v25.90 — Stable Master Build

This is a cumulative research/simulation master build. It carries forward the v25.70 strategy-import and multi-strategy work and appends v25.75, v25.80, v25.85, and v25.90 hardening iterations.

Live brokerage and live order submission are disabled.

Use `docs/Master_Build_Progress_Cumulative_v25.md` for the running build history and `docs/User_Manual_Cumulative_v25.md` for the current user manual. Original strategy artifacts remain under the quarantine tree and are fingerprinted by the cumulative quarantine manifest.
